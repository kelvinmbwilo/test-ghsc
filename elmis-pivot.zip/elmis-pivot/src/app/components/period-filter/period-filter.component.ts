import {
  Component, OnInit, Output, Input, EventEmitter, ViewChild, AfterViewInit,
  ChangeDetectionStrategy, OnChanges, SimpleChanges
} from '@angular/core';
import {Http} from "@angular/http";
import {_keyValueDiffersFactory} from "@angular/core/src/application_module";


const PERIOD_TYPE: Array<any> = [
  {value:'Monthly', name: 'Monthly', shown: true},
  {value:'BiMonthly', name: 'BiMonthly', shown: false},
  {value:'Quarterly', name: 'Quarterly', shown: true},
  {value:'SixMonthly', name: 'Six-Monthly', shown: false},
  {value:'SixMonthlyApril', name: 'Six-Monthly April', shown: false},
  {value:'Yearly', name: 'Yearly', shown: true},
  {value:'FinancialApril', name: 'Financial-April', shown: false},
  {value:'FinancialJuly', name: 'Financial-July', shown: true},
  {value:'FinancialOct', name: 'Financial-Oct', shown: false},
  {value:'RelativeMonth', name: 'Relative Month', shown: true},
  {value:'RelativeQuarter', name: 'Relative Quarter', shown: true},
  {value:'RelativeYear', name: 'Relative Year', shown: true},
  {value:'RelativeFinancialYear', name: 'Relative Financial Year', shown: true},
];


@Component({
  selector: '[app-period-filter]',
  templateUrl: './period-filter.component.html',
  styleUrls: ['./period-filter.component.css']
})
export class PeriodFilterComponent implements OnInit {

  @Input() period_tree_config: any = {
    show_search : false,
    search_text : 'Search',
    level: null,
    loading: false,
    loading_message: 'Loading Periods...',
    multiple: false,
    multiple_key:"none", //can be control or shift
    starting_periods: [],
    starting_year: null,
    placeholder: "Select period"
  };
  @Input() hideMonth:boolean = false;
  @Input() hideQuarter:boolean = false;
  @Input() selected_periods:any[] = [];
  period_type: string = 'QuarterlyA';
  @Input() starting_year: number = new Date().getFullYear();
  @Output() onPeriodUpdate: EventEmitter<any> = new EventEmitter<any>();
  @Output() onYearUpdate: EventEmitter<any> = new EventEmitter<any>();
  @Output() onTypeUpdate: EventEmitter<any> = new EventEmitter<any>();
  periods = [];
  period: any = {};
  showPerTree:boolean = false;
  year: number = new Date().getFullYear();
  default_period: string[] = [];
  customTemplateStringOrgunitOptions: any;
  period_type_config: Array<any>;

  constructor(
    private http: Http
  ) {
    let date = new Date();
    date.setDate(0);
    this.period_tree_config.starting_year = date.getFullYear();
    this.year = (this.period_tree_config.starting_year)?this.period_tree_config.starting_year:date.getFullYear();
    let datestring = date.getFullYear() + ("0"+(date.getMonth()+1)).slice(-2);
    this.period_tree_config.starting_periods=[datestring];
    if(!this.period_tree_config.hasOwnProperty("multiple_key")){
      this.period_tree_config.multiple_key = "none";
    }

    this.getSystemSettings().subscribe((value) => {
      // TODO: Find a way to find the relative period dynamic
      //this.activatePer({ id:value.keyAnalysisRelativePeriod, name:"Last 12 Month" })
    })
  }

  getSystemSettings(){
    return this.http.get("../../../api/25/systemSettings")
      .map(res => res.json() || {})
  }

  ngOnInit() {
    this.period_type_config = PERIOD_TYPE;
    if(this.period_type != '') {
      this.changePeriodType();
    }
  }


  transferDataSuccess(data,current){
    if(data.dragData.id == current.id){
    }else{
      let number = (this.getPeriodPosition(data.dragData.id) > this.getPeriodPosition(current.id))?0:1;
      this.deletePeriod( data.dragData );
      this.insertPeriod( data.dragData, current, number);
    }
  }

  // transfer all period to selected section
  selectAllItems(){
    this.periods.forEach((item) => {
      if(!this.checkPeriodAvailabilty(item, this.selected_periods )){
        this.selected_periods.push(item);
      }
    })
  }

  deselectAllItems(){
    this.selected_periods = [];
  }

  // helper method to find the index of dragged item
  getPeriodPosition(period_id){
    let period_index = null;
    this.selected_periods.forEach((period, index) => {
      if(period.id == period_id){
        period_index = index;
      }
    });
    return period_index;
  }

  // help method to delete the selected period in list before inserting it in another position
  deletePeriod( period_to_delete ){
    this.selected_periods.forEach((period, period_index) => {
      if( period_to_delete.id == period.id){
        this.selected_periods.splice(period_index,1);
      }
    });
  }

  // Helper method to insert period in new position after drag drop event
  insertPeriod( period_to_insert, current_period, num:number ){
    this.selected_periods.forEach((period, period_index) => {
      if( current_period.id == period.id && !this.checkPeriodAvailabilty(period_to_insert,this.selected_periods) ){
        this.selected_periods.splice(period_index+num,0,period_to_insert);
      }
    });
  }

  pushPeriodForward(){
    this.year += 1;
    this.periods = this.getPeriodArray(this.period_type,this.year);
    this.onYearUpdate.emit(this.year);
  }

  pushPeriodBackward(){
    this.year -= 1;
    this.periods = this.getPeriodArray(this.period_type,this.year);
    this.onYearUpdate.emit(this.year);
  }

  changePeriodType(){
    this.selected_periods = [];
    this.periods = this.getPeriodArray(this.period_type,this.year);
    this.onTypeUpdate.emit(this.period_type);
  }

  // action to be called when a tree item is deselected(Remove item in array of selected items
  deactivatePer ( $event ) {
    this.selected_periods.splice(this.selected_periods.indexOf($event),1);
    //TODO FIND BEST WAY TO EMIT SELECTED PERIOD
    this.onPeriodUpdate.emit({
      items: this.selected_periods,
      type: this.period_type,
      starting_year: this.starting_year,
      name: 'pe',
      value: this.getPeriodsForAnalytics(this.selected_periods)});

  };

  // add item to array of selected items when item is selected
  activatePer($event) {
    if(!this.checkPeriodAvailabilty($event,this.selected_periods)){
      this.selected_periods.push($event);
      //TODO FIND BEST WAY TO EMIT SELECTED PERIOD
      this.onPeriodUpdate.emit({
        items: this.selected_periods,
        type: this.period_type,
        starting_year: this.starting_year,
        name: 'pe',
        value: this.getPeriodsForAnalytics(this.selected_periods)
      });
    }
  };


  getPeriodsForAnalytics(selectedPeriod) {
    let periodForAnalytics = "";
    selectedPeriod.forEach((periodValue, periodIndex) => {
      periodForAnalytics += periodIndex == 0 ? periodValue.id : ';' + periodValue.id;
    });
    return periodForAnalytics
  }

  // check if orgunit already exist in the orgunit display list
  checkPeriodAvailabilty(period, array): boolean{
    let checker = false;
    for( let per of array ){
      if( per.id == period.id){
        checker =true;
      }
    }
    return checker;
  }

  resetSelection(hideMonth,hideQuarter){
    if( !hideMonth && !hideQuarter && this.period_type != "Quarterly" && this.period_type != "FinancialJuly" && this.period_type != "Yearly"){
      this.period_type = "QuarterlyA";
    }else if( hideMonth && !hideQuarter && this.period_type != "FinancialJuly" && this.period_type != "Yearly" ){
      this.period_type = "QuarterlyA";
    }else{
      this.period_type = "QuarterlyA";
    }


    this.periods = this.getPeriodArray(this.period_type,this.year);
  }



  getPeriodArray(type,year){
    let periods = [];
    let next_year = parseInt(year+1);
    if(type == "Weekly"){
      periods.push({id:'',name:''})
    }else if(type == "QuarterlyA"){
      periods.push({id:year+'12',name:'October - December '+year},{id:year+'09',name:'July - September '+year},{id:year+'06',name:'April - June '+year},{id:year+'03',name:'January - March '+year,selected:true})
    }else if(type == "QuarterlyB"){
      periods.push({id:next_year+'01',name:'November '+year+' - January '+next_year},{id:year+'10',name:'August - October '+year},{id:year+'07',name:'May - July '+year},{id:year+'04',name:'February - April '+year,selected:true})
    }else if(type == "QuarterlyC"){
      periods.push({id:next_year+'02',name:'December '+year+' - February '+next_year},{id:year+'11',name:'September - November '+year},{id:year+'08',name:'June - August '+year},{id:year+'05',name:'March - May '+year,selected:true})
    }
    return periods;
  }

  getName(period){
    let year = period.substring(0,4);
    let last_year = parseInt(year) - 1;
    let month = period.substring(4,6);
    let name = "";
    if(month == "01") {
      name = 'November '+last_year+' - January '+year
    }else if(month == "02"){
      name = 'December '+last_year+' - February '+year
    }else if(month == "03"){
      name = 'January - March '+year
    }else if(month == "04"){
      name = 'February - April '+year
    }else if(month == "05"){
      name = 'March - May '+year
    }else if(month == "06"){
      name = 'April - June '+year
    }else if(month == "07"){
      name = 'May - July '+year
    }else if(month == "08"){
      name = 'June - August '+year
    }else if(month == "09"){
      name = 'July - September '+year
    }else if(month == "10"){
      name = 'August - October '+year
    }else if(month == "11"){
      name = 'September - November '+year
    }else if(month == "12"){
      name = 'October - December '+year
    }
  }

  getLastPeriod(period: any, period_type:string ="Quarterly" ):any{
    if(period_type == "Weekly"){

    }
    else if(period_type == "Monthly"){
      let year = period.substring(0,4);
      let month = period.substring(4,6);
      let time = "";
      if(month == "02"){
        time = year+"01";
      }else if(month == "03"){
        time = year+"02";
      }else if(month == "04"){
        time = year+"03";
      }else if(month == "05"){
        time = year+"04";
      }else if(month == "06"){
        time = year+"05";
      }else if(month == "07"){
        time = year+"06";
      }else if(month == "08"){
        time = year+"07";
      }else if(month == "09"){
        time = year+"08";
      }else if(month == "10"){
        time = year+"09";
      }else if(month == "11"){
        time = year+"10";
      }else if(month == "12"){
        time = year+"11";
      }else if(month == "01"){
        let yr = parseInt(year)-1;
        time = yr+"12";
      }
      return time;
    }
    else if(period_type == "BiMonthly"){
      let year = period.substring(0,4);
      let month = period.substring(4,6);
      let time = "";
      if(month == "02"){
        time = year+"01B";
      }else if(month == "03"){
        time = year+"02B";
      }else if(month == "04"){
        time = year+"03B";
      }else if(month == "05"){
        time = year+"04B";
      }else if(month == "06"){
        time = year+"05B";
      }else if(month == "01"){
        let yr = parseInt(year)-1;
        time = yr+"06B";
      }
      return time;
    }
    else if(period_type == "Quarterly"){
      let year = period.substring(0,4);
      let quater = period.substring(4,6);
      let time = "";
      if(quater == "Q4"){
        time = year+"Q3";
      }else if(quater == "Q3"){
        time = year+"Q2";
      }else if(quater == "Q2"){
        time = year+"Q1";
      }else if(quater == "Q1"){
        let yr = parseInt(year)-1;
        time = yr+"Q4";
      }
      return time;
    }
    else if(period_type == "SixMonthly"){
      let year = period.substring(0,4);
      let six_month = period.substring(4,6);
      let time = "";
      if(six_month == "S1"){
        let yr = parseInt(year)-1;
        time = yr+"S2";
      }else if(six_month == "S2"){
        time = year+"S1"
      }
      return time;
    }
    else if(period_type == "SixMonthlyApril"){
      let year = period.substring(0,4);
      let six_month = period.substring(4,12);
      let time = "";
      if(six_month == "AprilS2"){
        time = year+"AprilS1"
      }else if(six_month == "AprilS1"){
        let yr = parseInt(year)-1;
        time = yr+"AprilS2";
      }
      return time;
    }
    else if(period_type == "FinancialOct"){
      let year = period.substring(0,4);
      let last_year = parseInt(year) - 1;
      return last_year+"Oct"
    }
    else if(period_type == "Yearly"){
      return parseInt(period)-1;
    }
    else if(period_type == "FinancialJuly"){
      let year = period.substring(0,4);
      let last_year = parseInt(year) - 1;
      return last_year+"July"
    }
    else if(period_type == "FinancialApril"){
      let year = period.substring(0,4);
      let last_year = parseInt(year) - 1;
      return last_year+"April"
    }


  }

  getNextPeriod(period: any, period_type:string ="Quarterly"):any{
    if(period_type == "Weekly"){

    }
    else if(period_type == "Monthly"){
      let year = period.substring(0,4);
      let month = period.substring(4,6);
      let time = "";
      if(month == "02"){
        time = year+"03";
      }else if(month == "03"){
        time = year+"04";
      }else if(month == "04"){
        time = year+"05";
      }else if(month == "05"){
        time = year+"06";
      }else if(month == "06"){
        time = year+"07";
      }else if(month == "07"){
        time = year+"08";
      }else if(month == "08"){
        time = year+"09";
      }else if(month == "09"){
        time = year+"10";
      }else if(month == "10"){
        time = year+"11";
      }else if(month == "11"){
        time = year+"12";
      }else if(month == "12"){
        let yr = parseInt(year)+1;
        time = yr+"01";
      }else if(month == "01"){
        time = year+"02";
      }
      return time;
    }
    else if(period_type == "BiMonthly"){
      let year = period.substring(0,4);
      let month = period.substring(4,6);
      let time = "";
      if(month == "02"){
        time = year+"03B";
      }else if(month == "03"){
        time = year+"04B";
      }else if(month == "04"){
        time = year+"05B";
      }else if(month == "05"){
        time = year+"06B";
      }else if(month == "06"){
        let yr = parseInt(year)+1;
        time = yr+"01B";
      }else if(month == "01"){
        time = year+"02B";
      }
      return time;
    }
    else if(period_type == "Quarterly"){
      let year = period.substring(0,4);
      let quater = period.substring(4,6);
      let time = "";
      if(quater == "Q1"){
        time = year+"Q2";
      }else if(quater == "Q3"){
        time = year+"Q4";
      }else if(quater == "Q2"){
        time = year+"Q3";
      }else if(quater == "Q4"){
        let yr = parseInt(year)+1;
        time = yr+"Q1";
      }
      return time;
    }
    else if(period_type == "SixMonthly"){
      let year = period.substring(0,4);
      let six_month = period.substring(4,6);
      let time = "";
      if(six_month == "S2"){
        let yr = parseInt(year)+1;
        time = yr+"S1";
      }else if(six_month == "S1"){
        time = year+"S2"
      }
      return time;
    }
    else if(period_type == "SixMonthlyApril"){
      let year = period.substring(0,4);
      let six_month = period.substring(4,12);
      let time = "";
      if(six_month == "AprilS2"){
        let yr = parseInt(year)+1;
        time = yr+"AprilS1";
      }else if(six_month == "AprilS1"){
        time = year+"AprilS2"
      }
      return time;
    }
    else if(period_type == "FinancialOct"){
      let year = period.substring(0,4);
      let last_year = parseInt(year) + 1;
      return last_year+"Oct"
    }
    else if(period_type == "Yearly"){
      return parseInt(period)+1;
    }
    else if(period_type == "FinancialJuly"){
      let year = period.substring(0,4);
      let last_year = parseInt(year) + 1;
      return last_year+"July"
    }
    else if(period_type == "FinancialApril"){
      let year = period.substring(0,4);
      let last_year = parseInt(year) + 1;
      return last_year+"April"
    }
  }

}
