export interface DataElement {
  id: string;
  name: string;
  categoryCombo: {
    id: string
  },
  dataSetElements: any[];
}
