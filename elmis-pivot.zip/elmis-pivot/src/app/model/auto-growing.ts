/**
 * Created by kelvin on 5/15/17.
 */
export interface AutoGrowing {
  id: string;
  name: string;
}
