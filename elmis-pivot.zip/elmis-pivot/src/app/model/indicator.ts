export interface Indicator {
  id: string;
  name: string;
}
