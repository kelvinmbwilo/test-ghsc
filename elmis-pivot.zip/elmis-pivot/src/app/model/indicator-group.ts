export interface IndicatorGroup {

}
