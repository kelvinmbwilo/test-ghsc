export class DataelementGroup {
}
