export class SelectedPeriod {

}
