export interface CategoryOptionCombo {
  id: string;
  name: string;
}
