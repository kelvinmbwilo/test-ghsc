
export interface DataSet {
  id: string;
  name:string;
}
