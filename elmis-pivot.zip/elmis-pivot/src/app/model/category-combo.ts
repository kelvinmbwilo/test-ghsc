
import {CategoryOptionCombo} from "./category-option-combo";
export interface CategoryCombo {
  id: string;
  name:string;
  categoryOptionCombos: CategoryOptionCombo[];
}
