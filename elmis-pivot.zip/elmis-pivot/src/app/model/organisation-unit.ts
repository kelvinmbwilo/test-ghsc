export class OrganisationUnit {
  id: string;
  name: string;
  parent: any;
  children: any;
}
