/**
 * Created by kelvin on 5/11/17.
 */
const analytics = []
