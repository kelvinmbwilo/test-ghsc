import { DraggableDirectiveDirective } from './draggable-directive.directive';

describe('DraggableDirectiveDirective', () => {
  it('should create an instance', () => {
    const directive = new DraggableDirectiveDirective();
    expect(directive).toBeTruthy();
  });
});
